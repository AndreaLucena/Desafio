package DesafioQuesito1;

import java.util.Scanner;

public class Almanaque extends Livro{
	
	public Almanaque(){
		super();		
	}
	
	public Almanaque(String titulo, String autor, int totalPaginas,
			int paginaAtual, boolean aberto, Pessoa pessoa) {
		super(titulo, autor, totalPaginas, paginaAtual, aberto, pessoa);
	}
	
	public void folhear(){
		System.out.println("Digite a página que deseja folhear a partir do índice");
		Scanner leTeclado = new Scanner(System.in);
				int pagina = leTeclado.nextInt();
		if (super.getAberto() == true && pagina>=1 && pagina <= super.getTotalPaginas()){
			super.setPaginaAtual(pagina);
		}
			System.out.println("Não é possível folhear.");
	}
	public void avancaPagina(){
		if ( super.getAberto() == true && super.getPaginaAtual() < super.getTotalPaginas()){
			super.setPaginaAtual(super.getPaginaAtual()+2);
		}
		System.out.println("Não é possível avançar a página.");
	}
}