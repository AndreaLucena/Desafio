package DesafioQuesito1;

public interface Publicacao {
	
	
	public void abrir();
	
	public void fechar();
	
	public void folhear(int pagina);
	
	public void avancaPagina();
	
	public void voltarPagina();

}
