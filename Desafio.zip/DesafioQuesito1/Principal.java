package DesafioQuesito1;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		Pessoa pessoa1 = new Pessoa();
		pessoa1.setNome("Maria");
		pessoa1.setIdade(19);
		pessoa1.setSexo("feminino");
		
		Pessoa pessoa2 = new Pessoa();
		pessoa2.setNome("João");
		pessoa2.setIdade(36);
		pessoa2.setSexo("masculino");
		
		Livro livro1 = new Livro();
		livro1.setTitulo("O Alquimista");
		livro1.setAutor("Paulo Coelho");
		livro1.setTotalPaginas(156);
		livro1.setPessoa(pessoa2);
		
		Livro livro2 = new Livro();
		livro2.setTitulo("Capitães de Areia");
		livro2.setAutor("Jorge Amado");
		livro2.setTotalPaginas(126);
		livro2.setPessoa(pessoa1);
		
		Livro livro3 = new Livro();
		livro3.setTitulo("Memórias Póstumas");
		livro3.setAutor("Machado de Assis");
		livro3.setTotalPaginas(456);
		livro3.setPessoa(pessoa2);
		
		Almanaque almanaque1 = new Almanaque();
		almanaque1.setTitulo("Almanaque_Vol.1");
		almanaque1.setAutor("EditoraNews");
		almanaque1.setTotalPaginas(456);
		almanaque1.setPessoa(pessoa2);
		
		Almanaque almanaque2 = new Almanaque();
		almanaque2.setTitulo("Almanaque_Vol.2");
		almanaque2.setAutor("EditoraNews");
		almanaque2.setTotalPaginas(456);
		almanaque2.setPessoa(pessoa2);
	
		System.out.println(livro1.detalhes());
		System.out.println(livro2.detalhes());
		System.out.println(livro3.detalhes());
		
		System.out.println(almanaque1.detalhes());
		System.out.println(almanaque2.detalhes());
		
		System.out.println("/n");
		System.out.println("*Livro 1*");
		livro1.abrir();
		livro2.avancaPagina();
		livro1.avancaPagina();
		livro1.folhear(38);
		livro2.avancaPagina();
		
		System.out.println(livro1.detalhes());
		
		System.out.println("/n");
		System.out.println("*Livro 2*");
		livro2.abrir();
		livro2.voltarPagina();
		livro2.avancaPagina();
		livro2.folhear(38);
		livro2.avancaPagina();
		livro2.voltarPagina();
		
		System.out.println(livro2.detalhes());
		
		System.out.println("/n");
		System.out.println("*Livro 3*");
		livro3.abrir();
		livro3.voltarPagina();
		livro3.avancaPagina();
		livro3.folhear(38);
		livro3.avancaPagina();
		livro3.voltarPagina();
		
		System.out.println(livro3.detalhes());
		
		
		
	}
}
